module.exports = (sequelize, Sequelize) => {
  const usrGame = sequelize.define("user_game", {
    username: {
      type: Sequelize.STRING,
      allowNull: false,
      primaryKey: true    
    },
    
    email: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    
    password: {
      type: Sequelize.STRING,
      allowNull: false,
    },
  });

  return usrGame;
};
