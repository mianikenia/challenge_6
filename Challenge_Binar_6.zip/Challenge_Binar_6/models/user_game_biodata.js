module.exports = (sequelize, Sequelize) => {
  const usrGamebiodata = sequelize.define("user_game_biodata", {
    username: {
      type: Sequelize.STRING,
      allowNull: false,
    },

    firstname: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    lastname: {
      type: Sequelize.STRING,
      allowNull: false,
    },
  });

  return usrGamebiodata;
};
