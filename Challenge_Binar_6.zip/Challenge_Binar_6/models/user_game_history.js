module.exports = (sequelize, Sequelize) => {
  const usrGamehistory = sequelize.define("user_game_history", {
    username: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    history_id: {
      type: Sequelize.STRING,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },

    time_stamp: {
      type: 'TIMESTAMP',
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      allowNull: false
    },

    result: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    score: {
      type: Sequelize.INTEGER,
      allowNull: true,
    },
  });

  return usrGamehistory;
};
